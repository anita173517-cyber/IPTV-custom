package com.harindra.iptvpro

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.Collections

/**
 * Upgrade 1: Ultra-Fast Random Zap Engine (3-Tier Smart Background CacheWriter Pre-Fetcher)
 * backed by a thread-safe 24 MB SimpleCache in cacheDir.
 *
 * Tier 1: Adjacent Channels (N+1 & N-1) — pre-warms manifest + up to 512 KB after playback starts.
 * Tier 2: D-Pad List Focus Pre-Fetch (>180ms focus) — pre-warms manifest + up to 256 KB before OK is pressed.
 * Tier 3: Top-8 Favorites/Recents Round-Robin Warmup — pre-warms manifest + up to 192 KB during idle playback.
 */
@OptIn(UnstableApi::class)
object StreamPreFetcher {
    private const val MAX_SIMPLE_CACHE_BYTES = 24L * 1024L * 1024L // Strictly 24 MB cap in cacheDir
    private const val TIER1_ADJACENT_BYTES = 512L * 1024L          // 512 KB
    private const val TIER2_FOCUS_BYTES = 256L * 1024L             // 256 KB
    private const val TIER3_WARMUP_BYTES = 192L * 1024L            // 192 KB
    private const val MIN_FREE_HEAP_FOR_PREFETCH = 20L * 1024L * 1024L // 20 MB guard

    @Volatile
    private var simpleCache: SimpleCache? = null
    private var cacheDirFile: File? = null

    private val prefetchScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var adjacentJob: Job? = null
    private var focusJob: Job? = null
    private var top8WarmupJob: Job? = null

    private val warmedUrls = Collections.synchronizedSet( LinkedHashSet<String>(64) )

    @Synchronized
    fun getOrCreateSimpleCache(context: Context): SimpleCache {
        simpleCache?.let { return it }
        val dir = File(context.applicationContext.cacheDir, "streamx_quantum_zap_cache")
        if (!dir.exists()) dir.mkdirs()
        cacheDirFile = dir
        val evictor = LeastRecentlyUsedCacheEvictor(MAX_SIMPLE_CACHE_BYTES)
        val dbProvider = StandaloneDatabaseProvider(context.applicationContext)
        return SimpleCache(dir, evictor, dbProvider).also {
            simpleCache = it
        }
    }

    fun buildCacheDataSourceFactory(
        context: Context,
        upstreamFactory: OkHttpDataSource.Factory
    ): CacheDataSource.Factory {
        val cache = getOrCreateSimpleCache(context)
        return CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(upstreamFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    private fun hasSafeHeapForPrefetch(): Boolean {
        val rt = Runtime.getRuntime()
        val freeAndUnallocated = rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
        return freeAndUnallocated >= MIN_FREE_HEAP_FOR_PREFETCH
    }

    /**
     * Tier 1: Silently pre-cache adjacent channels (N+1 and N-1) up to 512 KB after playback starts.
     */
    fun scheduleAdjacentPrefetch(
        context: Context,
        nextUrl: String?,
        prevUrl: String?
    ) {
        adjacentJob?.cancel()
        adjacentJob = prefetchScope.launch {
            delay(650L) // Let active stream render first frame without bandwidth competition
            if (!isActive || !hasSafeHeapForPrefetch()) return@launch
            if (!nextUrl.isNullOrBlank()) {
                prewarmUrlPrefix(context, nextUrl, TIER1_ADJACENT_BYTES)
            }
            if (!isActive || !hasSafeHeapForPrefetch()) return@launch
            if (!prevUrl.isNullOrBlank() && prevUrl != nextUrl) {
                prewarmUrlPrefix(context, prevUrl, TIER1_ADJACENT_BYTES)
            }
        }
    }

    /**
     * Tier 2: When user highlights a channel in the drawer for >180ms, pre-fetch manifest + 256 KB before OK is pressed.
     */
    fun scheduleFocusPrefetch(context: Context, focusedUrl: String?) {
        focusJob?.cancel()
        if (focusedUrl.isNullOrBlank()) return
        focusJob = prefetchScope.launch {
            delay(180L) // 180ms D-Pad focus debounce
            if (!isActive || !hasSafeHeapForPrefetch()) return@launch
            prewarmUrlPrefix(context, focusedUrl, TIER2_FOCUS_BYTES)
        }
    }

    /**
     * Tier 3: During idle playback, round-robin pre-warm up to 8 Favorite/Recent channels (192 KB each).
     */
    fun scheduleTop8Warmup(context: Context, topUrls: List<String>) {
        top8WarmupJob?.cancel()
        if (topUrls.isEmpty()) return
        top8WarmupJob = prefetchScope.launch {
            delay(3500L) // Wait until live playback is completely stable
            for (url in topUrls.take(8)) {
                if (!isActive || !hasSafeHeapForPrefetch()) break
                if (!warmedUrls.contains(url)) {
                    prewarmUrlPrefix(context, url, TIER3_WARMUP_BYTES)
                    delay(900L)
                }
            }
        }
    }

    private fun prewarmUrlPrefix(context: Context, streamUrl: String, maxBytes: Long) {
        if (!streamUrl.startsWith("http://", true) && !streamUrl.startsWith("https://", true)) return
        try {
            val cache = getOrCreateSimpleCache(context)
            val upstream = OkHttpDataSource.Factory(NetworkClient.fastMetaClient)
                .setUserAgent("StreamX-Media3Pro/12.0-QuantumLite (AndroidTV)")
            val cacheDataSource = CacheDataSource.Factory()
                .setCache(cache)
                .setUpstreamDataSourceFactory(upstream)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
                .createDataSource()

            val dataSpec = DataSpec.Builder()
                .setUri(Uri.parse(streamUrl))
                .setPosition(0L)
                .setLength(maxBytes)
                .build()

            val tempBuffer = ByteArray(16 * 1024)
            val writer = CacheWriter(
                cacheDataSource,
                dataSpec,
                tempBuffer
            ) { _, bytesCached, _ ->
                if (bytesCached >= maxBytes || !hasSafeHeapForPrefetch()) {
                    throw InterruptedException("Prefetch budget reached")
                }
            }
            writer.cache()
            synchronized(warmedUrls) {
                if (warmedUrls.size >= 48) {
                    val first = warmedUrls.iterator().next()
                    warmedUrls.remove(first)
                }
                warmedUrls.add(streamUrl)
            }
        } catch (_: InterruptedException) {
            // Normal budget cap completion
        } catch (e: Exception) {
            Log.d("StreamX", "Prefetch skipped for $streamUrl: ${e.message}")
        }
    }

    fun cancelAllPrefetches() {
        adjacentJob?.cancel()
        focusJob?.cancel()
        top8WarmupJob?.cancel()
    }

    fun trimIdleCacheOnLowMemory() {
        cancelAllPrefetches()
        warmedUrls.clear()
    }

    fun cacheUsedBytes(): Long {
        return try {
            simpleCache?.cacheSpace ?: 0L
        } catch (_: Exception) {
            0L
        }
    }
}
