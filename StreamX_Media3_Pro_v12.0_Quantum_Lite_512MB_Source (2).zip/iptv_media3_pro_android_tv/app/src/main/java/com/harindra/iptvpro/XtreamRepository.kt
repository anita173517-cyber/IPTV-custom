package com.harindra.iptvpro

import android.util.JsonReader
import android.util.JsonToken
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import kotlin.coroutines.coroutineContext

class XtreamRepository {
    companion object {
        private const val DEFAULT_MAX_STREAMS = 60_000
    }

    private fun apiUrl(base: String, creds: XtreamCredentials, action: String): String {
        val normalizedBase = if (base.startsWith("http://", true) || base.startsWith("https://", true)) {
            base
        } else {
            "http://$base"
        }
        val parsed = normalizedBase.toHttpUrlOrNull() ?: throw IllegalArgumentException("Invalid server URL")
        return parsed.newBuilder()
            .addPathSegment("player_api.php")
            .addQueryParameter("username", creds.username)
            .addQueryParameter("password", creds.password)
            .addQueryParameter("action", action)
            .build()
            .toString()
    }

    private fun readStringSafe(reader: JsonReader, default: String = ""): String {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.STRING, JsonToken.NUMBER -> reader.nextString()
            JsonToken.BOOLEAN -> reader.nextBoolean().toString()
            else -> {
                reader.skipValue()
                default
            }
        }
    }

    private fun readIntSafe(reader: JsonReader, default: Int): Int {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.NUMBER -> runCatching { reader.nextInt() }.getOrElse {
                runCatching { reader.nextString().toIntOrNull() ?: default }.getOrDefault(default)
            }
            JsonToken.STRING -> reader.nextString().toIntOrNull() ?: default
            else -> {
                reader.skipValue()
                default
            }
        }
    }

    suspend fun fetchLiveStreams(
        creds: XtreamCredentials,
        maxStreams: Int = DEFAULT_MAX_STREAMS,
        onFirstBatchReady: (suspend (List<Channel>) -> Unit)? = null
    ): Result<List<Channel>> = withContext(Dispatchers.IO) {
        try {
            val rawBase = creds.serverUrl.trim().removeSuffix("/")
            val cleanBase = if (rawBase.startsWith("http://", true) || rawBase.startsWith("https://", true)) {
                rawBase
            } else {
                "http://$rawBase"
            }
            val categoriesMap = HashMap<String, String>(128)

            // 1. Stream Live Categories with fastMetaClient (8s connect / 12s read timeout)
            val catUrl = apiUrl(cleanBase, creds, "get_live_categories")
            try {
                NetworkClient.fastMetaClient.newCall(Request.Builder().url(catUrl).build()).execute().use { res ->
                    val body = res.body
                    if (res.isSuccessful && body != null) {
                        JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 8192)).use { reader ->
                            if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                                reader.beginArray()
                                while (reader.hasNext()) {
                                    coroutineContext.ensureActive()
                                    if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                                        reader.skipValue()
                                        continue
                                    }
                                    var catId = ""
                                    var catName = "Live TV"
                                    reader.beginObject()
                                    while (reader.hasNext()) {
                                        when (reader.nextName()) {
                                            "category_id" -> catId = readStringSafe(reader)
                                            "category_name" -> catName = readStringSafe(reader, "Live TV").trim().ifBlank { "Live TV" }
                                            else -> reader.skipValue()
                                        }
                                    }
                                    reader.endObject()
                                    if (catId.isNotEmpty()) {
                                        categoriesMap[catId] = catName
                                    }
                                }
                                reader.endArray()
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                coroutineContext.ensureActive()
                Log.w("StreamX", "Category fetch warning (continuing with stream list): ${e.message}")
            }

            // 2. Stream Live Channels with JsonReader + Progressive First Batch + Auto-Failover Backup Grouping
            val streamsUrl = apiUrl(cleanBase, creds, "get_live_streams")
            NetworkClient.apiClient.newCall(Request.Builder().url(streamsUrl).build()).execute().use { res ->
                if (!res.isSuccessful) return@withContext Result.failure(Exception("HTTP ${res.code}"))
                val body = res.body ?: return@withContext Result.failure(Exception("Empty server response"))

                val list = ArrayList<Channel>(2048)
                val seenIds = HashSet<String>(2048)
                val primaryIndexByNormName = HashMap<String, Int>(2048)
                val streamPrefix = "$cleanBase/live/${creds.username}/${creds.password}/"
                var firstBatchDispatched = false

                JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 16384)).use { reader ->
                    if (reader.peek() != JsonToken.BEGIN_ARRAY) {
                        return@withContext Result.failure(Exception("Invalid Xtream credentials or non-list response"))
                    }
                    reader.beginArray()
                    var index = 0
                    while (reader.hasNext() && list.size < maxStreams) {
                        if (index % 500 == 0) coroutineContext.ensureActive()
                        if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                            reader.skipValue()
                            continue
                        }
                        index++
                        var streamId = ""
                        var num = index
                        var name = ""
                        var catId = ""
                        var icon = ""
                        var epgChannelId = ""

                        reader.beginObject()
                        while (reader.hasNext()) {
                            when (reader.nextName()) {
                                "stream_id" -> streamId = readStringSafe(reader).trim()
                                "num" -> num = readIntSafe(reader, index)
                                "name" -> name = readStringSafe(reader).trim()
                                "category_id" -> catId = readStringSafe(reader).trim()
                                "stream_icon" -> icon = readStringSafe(reader).trim()
                                "epg_channel_id" -> epgChannelId = readStringSafe(reader).trim()
                                else -> reader.skipValue()
                            }
                        }
                        reader.endObject()

                        if (streamId.isNotEmpty() && seenIds.add(streamId)) {
                            val resolvedCategory = categoriesMap[catId] ?: "Live TV"
                            val resolvedName = name.ifBlank { "Channel ${list.size + 1}" }
                            val candidateUrl = "$streamPrefix$streamId.m3u8"
                            val normKey = "${resolvedCategory.lowercase(Locale.ROOT)}|${resolvedName.lowercase(Locale.ROOT)}"
                            val existingIdx = primaryIndexByNormName[normKey]
                            if (existingIdx != null && existingIdx in list.indices && list[existingIdx].backupUrl.isEmpty()) {
                                list[existingIdx] = list[existingIdx].copy(backupUrl = candidateUrl)
                            } else {
                                val resolvedNum = if (num > 0) num else list.size + 1
                                val newIdx = list.size
                                list.add(
                                    Channel(
                                        id = streamId,
                                        number = resolvedNum,
                                        name = resolvedName,
                                        category = resolvedCategory,
                                        streamUrl = candidateUrl,
                                        logoUrl = icon,
                                        epgId = epgChannelId
                                    )
                                )
                                primaryIndexByNormName.putIfAbsent(normKey, newIdx)
                                if (!firstBatchDispatched && list.size == 300 && onFirstBatchReady != null) {
                                    firstBatchDispatched = true
                                    onFirstBatchReady.invoke(ArrayList(list))
                                }
                            }
                        }
                    }
                    while (reader.hasNext()) {
                        reader.skipValue()
                    }
                    reader.endArray()
                }
                Result.success(list)
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Xtream fetchLiveStreams error", e)
            Result.failure(e)
        }
    }
}
